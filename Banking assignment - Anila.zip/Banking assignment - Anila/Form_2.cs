﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace usecase_try4
{
    public partial class Form_2 : Form
    {
        public Form_2()
        {
            InitializeComponent();
        }

        private void Form_2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bank_AppDataSet.details_2' table. You can move, or remove it, as needed.
            this.details_2TableAdapter.Fill(this.bank_AppDataSet.details_2);

        }
    }
}
